import math
import random
import time
from dataclasses import dataclass
from pathlib import Path

from PIL import Image, ImageDraw, ImageTk


BASE_DIR = Path(__file__).resolve().parent
INTRO_DIR = BASE_DIR / "sprites" / "intro"


@dataclass
class AmbientFlake:
    x: float
    y: float
    vy: float
    vx: float
    size: int
    phase: float


@dataclass
class LogoFlake:
    x: float
    y: float
    target_x: int
    target_y: int
    start_time: float
    fall_speed: float
    drift_phase: float
    drift_amount: float
    size: int
    settled: bool = False


class ChapterIntro:
    """Chapter 6 first-time intro.

    Sequence:
        black screen + IMAGE_LOGO_CENTER_HEART
        -> snow begins falling
        -> selected flakes settle into the shape of IMAGE_LOGO
        -> completed logo holds briefly
        -> fade to black
        -> game.py reveals File Select underneath black and fades it in

    The animation is rendered at DELTARUNE's 320x240 logical resolution and
    then nearest-neighbour scaled by Game, so the particles stay pixel crisp.
    """

    TAG = "chapter_intro"
    FRAME_MS = 33

    # --------------------------------------------------
    # Layout
    # --------------------------------------------------
    LOGO_CENTER_X = 160
    LOGO_CENTER_Y = 108
    HEART_CENTER_X = 160
    HEART_CENTER_Y = 108

    # These are deliberately easy to tune after seeing the animation in-game.
    LOGO_SCALE = 1.0
    HEART_SCALE = 1.0

    # --------------------------------------------------
    # Timing (seconds)
    # --------------------------------------------------
    SNOW_START = 0.15
    LOGO_SNOW_START = 0.45
    LOGO_FORM_END = 5.40
    LOGO_RESOLVE_START = 4.85
    LOGO_HOLD_END = 6.55
    FADE_TO_BLACK_END = 7.35

    # Z cannot skip on the very first frames.
    SKIP_SAFETY = 0.35
    SKIP_FADE_TIME = 0.45

    # --------------------------------------------------
    # Snow tuning
    # --------------------------------------------------
    AMBIENT_FLAKES_PER_SECOND = 26.0
    AMBIENT_SPEED_MIN = 22.0
    AMBIENT_SPEED_MAX = 48.0
    AMBIENT_DRIFT_MAX = 7.0

    TARGET_SPEED_MIN = 35.0
    TARGET_SPEED_MAX = 56.0
    TARGET_DRIFT_MAX = 2.5

    # One target flake for roughly every STEP x STEP visible logo block.
    # 1 = very dense, 2 = default, 3+ = increasingly sparse.
    LOGO_SAMPLE_STEP = 2

    def __init__(self, game, on_complete=None):
        self.game = game
        self.canvas = game.canvas
        self.on_complete = on_complete

        self.active = False
        self.finished = False
        self.started_at = 0.0
        self.last_update_at = 0.0

        self.skip_started_at = None
        self.ambient_spawn_accumulator = 0.0

        self.ambient_flakes = []
        self.logo_flakes = []
        self.pending_logo_flakes = []

        self.logo_pil = None
        self.heart_pil = None
        self.logo_x = 0
        self.logo_y = 0
        self.heart_x = 0
        self.heart_y = 0

        self.settled_logo = Image.new(
            "RGBA",
            (self.game.viewport_width, self.game.viewport_height),
            (0, 0, 0, 0),
        )

        # Full-canvas black rectangle keeps the widescreen/letterbox region
        # black even though the animation itself is only 320x240.
        self.black_background = self.canvas.create_rectangle(
            0, 0, 0, 0,
            fill="black",
            outline="",
            state="hidden",
            tags=(self.TAG,),
        )

        self.frame_item = self.canvas.create_image(
            0, 0,
            anchor="nw",
            state="hidden",
            tags=(self.TAG,),
        )
        self.frame_photo = None

        self._load_assets()
        self._build_logo_flake_schedule()

    # ==================================================
    # Asset loading
    # ==================================================

    @staticmethod
    def _find_asset(stem):
        if not INTRO_DIR.exists():
            raise FileNotFoundError(
                f"Chapter intro asset folder does not exist: {INTRO_DIR}"
            )

        stem_cf = stem.casefold()
        exact = []
        prefixed = []

        for path in INTRO_DIR.iterdir():
            if not path.is_file():
                continue

            if path.stem.casefold() == stem_cf:
                exact.append(path)
            elif path.stem.casefold().startswith(stem_cf + "_"):
                prefixed.append(path)

        matches = exact or prefixed
        if not matches:
            raise FileNotFoundError(
                f"Could not find {stem} in {INTRO_DIR}. "
                f"Expected a file such as {stem}.png"
            )

        return sorted(matches)[0]

    @staticmethod
    def _scaled_asset(image, scale):
        if scale == 1.0:
            return image

        width = max(1, round(image.width * scale))
        height = max(1, round(image.height * scale))
        return image.resize((width, height), Image.Resampling.NEAREST)

    def _load_assets(self):
        logo_path = self._find_asset("IMAGE_LOGO")
        heart_path = self._find_asset("IMAGE_LOGO_CENTER_HEART")

        self.logo_pil = Image.open(logo_path).convert("RGBA")
        self.heart_pil = Image.open(heart_path).convert("RGBA")

        self.logo_pil = self._scaled_asset(self.logo_pil, self.LOGO_SCALE)
        self.heart_pil = self._scaled_asset(self.heart_pil, self.HEART_SCALE)

        self.logo_x = round(self.LOGO_CENTER_X - self.logo_pil.width / 2)
        self.logo_y = round(self.LOGO_CENTER_Y - self.logo_pil.height / 2)
        self.heart_x = round(self.HEART_CENTER_X - self.heart_pil.width / 2)
        self.heart_y = round(self.HEART_CENTER_Y - self.heart_pil.height / 2)

    # ==================================================
    # Snow setup
    # ==================================================

    @staticmethod
    def _is_logo_pixel(pixel):
        r, g, b, a = pixel
        if a < 48:
            return False

        # Avoid treating an opaque black sprite background as part of the
        # logo. Actual white/bright logo pixels remain valid.
        return max(r, g, b) >= 80

    def _build_logo_flake_schedule(self):
        self.pending_logo_flakes.clear()

        pixels = self.logo_pil.load()
        step = max(1, int(self.LOGO_SAMPLE_STEP))
        targets = []

        for sy in range(0, self.logo_pil.height, step):
            for sx in range(0, self.logo_pil.width, step):
                found_visible = False

                # For STEP > 1, preserve thin parts of the logo if *any*
                # pixel inside this block is visible.
                for oy in range(step):
                    py = sy + oy
                    if py >= self.logo_pil.height:
                        break

                    for ox in range(step):
                        px = sx + ox
                        if px >= self.logo_pil.width:
                            break

                        if self._is_logo_pixel(pixels[px, py]):
                            found_visible = True
                            break

                    if found_visible:
                        break

                if found_visible:
                    targets.append((self.logo_x + sx, self.logo_y + sy))

        random.shuffle(targets)

        for target_x, target_y in targets:
            # Most of the logo appears gradually and non-linearly rather than
            # as a strict top-to-bottom wipe. Lower targets get a small extra
            # delay, but random timing remains dominant.
            normalized_y = max(0.0, min(1.0, target_y / 240.0))
            start_time = random.uniform(
                self.LOGO_SNOW_START,
                max(self.LOGO_SNOW_START, self.LOGO_FORM_END - 1.25),
            )
            start_time += normalized_y * random.uniform(0.0, 0.65)
            start_time = min(start_time, self.LOGO_FORM_END - 0.55)

            speed = random.uniform(self.TARGET_SPEED_MIN, self.TARGET_SPEED_MAX)
            travel_time = max(0.45, target_y / max(speed, 1.0))

            # Start high enough that each target flake reaches its destination
            # around/after its scheduled appearance time.
            start_y = target_y - (speed * travel_time) - random.uniform(8, 40)
            start_y = min(start_y, random.uniform(-55, -4))
            start_x = target_x + random.uniform(-18, 18)

            self.pending_logo_flakes.append(
                LogoFlake(
                    x=start_x,
                    y=start_y,
                    target_x=target_x,
                    target_y=target_y,
                    start_time=start_time,
                    fall_speed=speed,
                    drift_phase=random.uniform(0, math.tau),
                    drift_amount=random.uniform(0.25, self.TARGET_DRIFT_MAX),
                    size=step,
                )
            )

        self.pending_logo_flakes.sort(key=lambda flake: flake.start_time)

    # ==================================================
    # Lifecycle
    # ==================================================

    def start(self):
        self.active = True
        self.finished = False
        self.started_at = time.perf_counter()
        self.last_update_at = self.started_at
        self.skip_started_at = None

        self.ambient_spawn_accumulator = 0.0
        self.ambient_flakes.clear()
        self.logo_flakes.clear()
        self.settled_logo = Image.new(
            "RGBA",
            (self.game.viewport_width, self.game.viewport_height),
            (0, 0, 0, 0),
        )
        self._build_logo_flake_schedule()

        try:
            self.game.audio.stop_music()
        except Exception:
            pass

        self.show()
        self.render()

    def show(self):
        self.canvas.itemconfigure(self.TAG, state="normal")
        self.canvas.tag_raise(self.TAG)

    def hide(self):
        self.canvas.itemconfigure(self.TAG, state="hidden")

    def handle_input(self, key):
        if not self.active or key != "z":
            return

        elapsed = time.perf_counter() - self.started_at
        if elapsed < self.SKIP_SAFETY:
            return

        if self.skip_started_at is None:
            self.skip_started_at = time.perf_counter()

    # ==================================================
    # Update
    # ==================================================

    def _spawn_ambient(self, dt):
        elapsed = time.perf_counter() - self.started_at
        if elapsed < self.SNOW_START:
            return

        self.ambient_spawn_accumulator += self.AMBIENT_FLAKES_PER_SECOND * dt

        while self.ambient_spawn_accumulator >= 1.0:
            self.ambient_spawn_accumulator -= 1.0

            self.ambient_flakes.append(
                AmbientFlake(
                    x=random.uniform(0, self.game.viewport_width - 1),
                    y=random.uniform(-12, -1),
                    vy=random.uniform(
                        self.AMBIENT_SPEED_MIN,
                        self.AMBIENT_SPEED_MAX,
                    ),
                    vx=random.uniform(
                        -self.AMBIENT_DRIFT_MAX,
                        self.AMBIENT_DRIFT_MAX,
                    ),
                    size=random.choice((1, 1, 1, 2)),
                    phase=random.uniform(0, math.tau),
                )
            )

    def _activate_target_flakes(self, elapsed):
        while (
            self.pending_logo_flakes
            and self.pending_logo_flakes[0].start_time <= elapsed
        ):
            self.logo_flakes.append(self.pending_logo_flakes.pop(0))

    def _update_ambient(self, dt, elapsed):
        alive = []

        for flake in self.ambient_flakes:
            flake.phase += dt * 2.0
            flake.x += flake.vx * dt + math.sin(flake.phase) * 0.14
            flake.y += flake.vy * dt

            if flake.y < self.game.viewport_height + flake.size:
                alive.append(flake)

        self.ambient_flakes = alive

    def _settle_logo_flake(self, flake):
        draw = ImageDraw.Draw(self.settled_logo)
        size = max(1, flake.size)
        x0 = int(flake.target_x)
        y0 = int(flake.target_y)

        draw.rectangle(
            (x0, y0, x0 + size - 1, y0 + size - 1),
            fill=(255, 255, 255, 255),
        )

    def _update_logo_flakes(self, dt, elapsed):
        still_falling = []

        for flake in self.logo_flakes:
            if flake.settled:
                continue

            flake.drift_phase += dt * 2.5

            # Correct horizontal error gradually, with a tiny snow-like sway.
            x_error = flake.target_x - flake.x
            correction = x_error * min(1.0, dt * 3.0)
            sway = math.sin(flake.drift_phase) * flake.drift_amount * dt
            flake.x += correction + sway
            flake.y += flake.fall_speed * dt

            if flake.y >= flake.target_y:
                flake.x = flake.target_x
                flake.y = flake.target_y
                flake.settled = True
                self._settle_logo_flake(flake)
            else:
                still_falling.append(flake)

        self.logo_flakes = still_falling

    def update(self):
        if not self.active:
            return

        now = time.perf_counter()
        dt = min(now - self.last_update_at, 0.10)
        self.last_update_at = now
        elapsed = now - self.started_at

        # Z skip: immediately stop building the picture and fade to black.
        if self.skip_started_at is not None:
            if now - self.skip_started_at >= self.SKIP_FADE_TIME:
                self.finish()
            return

        self._spawn_ambient(dt)
        self._activate_target_flakes(elapsed)
        self._update_ambient(dt, elapsed)
        self._update_logo_flakes(dt, elapsed)

        if elapsed >= self.FADE_TO_BLACK_END:
            self.finish()

    # ==================================================
    # Rendering
    # ==================================================

    def _logo_resolve_alpha(self, elapsed):
        if elapsed <= self.LOGO_RESOLVE_START:
            return 0.0
        if elapsed >= self.LOGO_FORM_END:
            return 1.0

        return (
            (elapsed - self.LOGO_RESOLVE_START)
            / (self.LOGO_FORM_END - self.LOGO_RESOLVE_START)
        )

    def _black_fade_alpha(self, elapsed):
        if self.skip_started_at is not None:
            progress = (
                time.perf_counter() - self.skip_started_at
            ) / self.SKIP_FADE_TIME
            return max(0.0, min(1.0, progress))

        if elapsed <= self.LOGO_HOLD_END:
            return 0.0
        if elapsed >= self.FADE_TO_BLACK_END:
            return 1.0

        return (
            (elapsed - self.LOGO_HOLD_END)
            / (self.FADE_TO_BLACK_END - self.LOGO_HOLD_END)
        )

    @staticmethod
    def _draw_flake(draw, x, y, size):
        x = int(round(x))
        y = int(round(y))
        size = max(1, int(size))
        draw.rectangle(
            (x, y, x + size - 1, y + size - 1),
            fill=(255, 255, 255, 255),
        )

    def _logical_frame(self):
        elapsed = time.perf_counter() - self.started_at

        frame = Image.new(
            "RGBA",
            (self.game.viewport_width, self.game.viewport_height),
            (0, 0, 0, 255),
        )

        # Settled snow always sits behind the heart and the crisp logo.
        frame.alpha_composite(self.settled_logo)

        draw = ImageDraw.Draw(frame)

        for flake in self.ambient_flakes:
            self._draw_flake(draw, flake.x, flake.y, flake.size)

        for flake in self.logo_flakes:
            self._draw_flake(draw, flake.x, flake.y, flake.size)

        # The heart is the one piece visible from the very beginning.
        frame.alpha_composite(
            self.heart_pil,
            dest=(self.heart_x, self.heart_y),
        )

        # Once enough snow has settled, crossfade the actual sprite on top so
        # the final logo is pixel-perfect rather than permanently stippled.
        resolve_alpha = self._logo_resolve_alpha(elapsed)
        if resolve_alpha > 0:
            logo = self.logo_pil.copy()
            if resolve_alpha < 1:
                alpha = logo.getchannel("A")
                alpha = alpha.point(
                    lambda value: int(value * resolve_alpha)
                )
                logo.putalpha(alpha)

            frame.alpha_composite(
                logo,
                dest=(self.logo_x, self.logo_y),
            )

        fade_alpha = self._black_fade_alpha(elapsed)
        if fade_alpha > 0:
            black = Image.new(
                "RGBA",
                frame.size,
                (0, 0, 0, round(255 * fade_alpha)),
            )
            frame = Image.alpha_composite(frame, black)

        return frame

    def render(self):
        if not self.active:
            return

        self.canvas.coords(
            self.black_background,
            0,
            0,
            self.canvas.winfo_width(),
            self.canvas.winfo_height(),
        )

        logical = self._logical_frame()
        scaled_width = max(1, round(self.game.viewport_width * self.game.scale))
        scaled_height = max(1, round(self.game.viewport_height * self.game.scale))
        scaled = logical.resize(
            (scaled_width, scaled_height),
            Image.Resampling.NEAREST,
        )

        self.frame_photo = ImageTk.PhotoImage(scaled)
        self.canvas.itemconfigure(
            self.frame_item,
            image=self.frame_photo,
            state="normal",
        )
        self.canvas.coords(
            self.frame_item,
            self.game.offset_x,
            self.game.offset_y,
        )

        self.canvas.tag_raise(self.black_background)
        self.canvas.tag_raise(self.frame_item)

    def finish(self):
        if self.finished:
            return

        self.finished = True
        self.active = False

        # Keep the intro visible until game.py has installed its own black
        # overlay over File Select. Game._hide_active_startup_screen() will
        # hide our canvas items during that handoff.
        if self.on_complete is not None:
            self.on_complete()
        else:
            self.hide()
